export enum PreferencesTab {
  Accounts = 0,
  Git = 1,
  Appearance = 2,
  Advanced = 3,
}
